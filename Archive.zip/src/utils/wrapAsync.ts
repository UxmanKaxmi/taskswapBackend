// src/utils/wrapAsync.ts
import { RequestHandler } from "express";

export const wrapAsync = (fn: RequestHandler): RequestHandler => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
